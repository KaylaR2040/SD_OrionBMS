/*
 * ===========================================================================
 * File: stm32g4xx_it.c
 * Description: Interrupt service routines for STM32G4 peripheral/CPU exceptions.
 *
 * Notes:
 *   - Generated layout retained; handlers may be customized for application needs.
 * ===========================================================================
 */

// STM32 HAL
#include "stm32g4xx_hal.h"
#include "stm32g4xx_hal_fdcan.h"

// Project headers
#include "log.h"
#include "main.h"

/* Non-maskable interrupt handler (left minimal for now) */
void NMI_Handler(void) {}

/* Trap unrecoverable CPU faults */
void HardFault_Handler(void) {
    while (1) {}
}

/* Supervisor call handler (unused) */
void SVC_Handler(void) {}

/* PendSV handler (unused in this project) */
void PendSV_Handler(void) {}

/* Tick interrupt increments the HAL time base */
void SysTick_Handler(void)
{
    HAL_IncTick();
}

/* Route FDCAN interrupt line 0 to HAL handler */
void FDCAN1_IT0_IRQHandler(void)
{
    HAL_FDCAN_IRQHandler(&g_fdcan1);
}

/* Route FDCAN interrupt line 1 to HAL handler */
void FDCAN1_IT1_IRQHandler(void)
{
    HAL_FDCAN_IRQHandler(&g_fdcan1);
}

/* UART2 interrupt handler used by logging interface */
void USART2_IRQHandler(void)
{
    HAL_UART_IRQHandler(&g_uart2);
}

/* TIM6 global interrupt handler */
extern TIM_HandleTypeDef g_htim6;

void TIM6_DAC_IRQHandler(void)
{
    HAL_TIM_IRQHandler(&g_htim6);
}
