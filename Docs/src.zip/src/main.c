/*
 * ===========================================================================
 * File: main.c
 * Description: Application entry point that dispatches ADC/SPI tasks.
 *
 * Notes:
 *   - Service tasks run every loop iteration; per-task timing lives in modules.
 * ===========================================================================
 */

// STM32 HAL
#include "stm32g4xx_hal.h"

// Project headers
#include "adc.h"
#include "can.h"
#include "clocks.h"
#include "init.h"
#include "led.h"
#include "log.h"
#include "main.h"
#include "spi.h"
#include "spi_max.h"

// C standard library
#include <stdbool.h>

/* Primary application entry point that initializes subsystems and runs tasks */
int main(void)
{
    /* Request ADC-driven LED PWM before other subsystems start up. */
    ADC_LedPwm_RequestEnable(true);

    System_AppInit();

    ADC_App_Init();
    SPI_App_Init();
    SPI_Max_Init();
    CAN_App_Init(1000U);
    Timer_Init();

    // Pulse all LEDs for 1 second to show init complete
    LED_All_Pulse(1000U);
    HAL_Delay(1000); // Pause for 1 second before starting tasks

    // See function definition in adc.c for more info on Freq options:
    // ADC_SetLedPwmFrequency(ADC_PWM_FREQ_DEMO_SLOW_KHZ); // ADC-driven LED PWM Flashes faster or slower based on ADC reading
    ADC_SetLedPwmFrequency(ADC_PWM_FREQ_DEMO_FAST_KHZ); // ADC-driven LED PWM dims/brightens based on ADC reading
    LOG_INFO("Init complete");    

    // Main application loop that runs periodic service tasks
    while (true) {
        /* Tasks now run every loop iteration (no startup or periodic delay). */
        /* Search for: "INST_TEST" to remove this functionality */
        ADC_ServiceTask();
        SPI_ServiceTask();
        CAN_ServiceTask();
        
        Debug_PollCommand();
    }
}
