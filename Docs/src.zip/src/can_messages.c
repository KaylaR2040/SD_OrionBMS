/*
 * File: can_messages.c
 * Description: CAN message encoding for thermistor modules and Orion BMS
 */

#include "can.h"
#include "can_messages.h"
#include "timer.h"
#include "log.h"
#include <string.h>
#include <stdbool.h>
#include "thermistor_table.h"

/* Storage for converted temperatures (updated by ADC fast path via ConvertAllThermistors) */
static int8_t s_temps[MAX_THERMISTORS] = {0};
static uint8_t s_num_temps = 0;

/* TX timestamp tracking for interval instrumentation */
static uint32_t s_last_100ms_tx_ms = 0U;
static uint32_t s_last_200ms_tx_ms = 0U;

/* Last transmitted payloads + measured intervals (debug commands / stream) */
static uint8_t  s_last_payload_claim[8]  = {0};
static uint8_t  s_last_payload_bms[8]    = {0};
static uint8_t  s_last_payload_gen[8]    = {0};
static uint32_t s_last_claim_interval_ms = 0U;
static uint32_t s_last_bms_interval_ms   = 0U;

/* UART command input buffer */
static char    s_cmd_buf[32];
static uint8_t s_cmd_len    = 0U;

/* Periodic UART stream (enabled by default, 500 ms period) */
static bool     s_stream_enabled = true;
static uint32_t s_stream_next_ms = 0U;

/* Module configuration (zero-based index):
 * thermistor_module = 0 → first module  (source address 0x80)
 * thermistor_module = 1 → second module (source address 0x81)
 * CAN source address = 0x80 + thermistor_module
 */
static const ThermJ1939ClaimMsg_t s_default_claim = {
    .unique_id = { 0xF3, 0x00, 0x80 },
    .bms_target = 0xF3,
    .thermistor_module = 0x00,  /* 0 = first module (source address 0x80) */
    .constant = { 0x40, 0x1E, 0x90 }
};

static uint8_t CAN_GetSourceAddress(void)
{
    return (uint8_t)(0x80U + s_default_claim.thermistor_module);
}

static uint32_t CAN_ApplySourceAddress(uint32_t base_id, uint8_t source_address)
{
    return (base_id & 0xFFFFFF00UL) | (uint32_t)source_address;
}

/* -------------------------------------------------------------------------- */
/* ADC to Temperature Conversion                                              */
/* -------------------------------------------------------------------------- */

void ConvertAllThermistors(const uint16_t *adc_values, uint8_t count)
{
    s_num_temps = (count > MAX_THERMISTORS) ? MAX_THERMISTORS : count;

    for (uint8_t i = 0; i < s_num_temps; i++) {
        s_temps[i] = Thermistor_ADCToTemp(adc_values[i]);
    }
}

/* -------------------------------------------------------------------------- */
/* Helper: Get Min/Max/Avg from converted temps                               */
/* -------------------------------------------------------------------------- */

static int8_t GetAvgTemp(void)
{
    if (s_num_temps == 0) return 0;
    
    int32_t sum = 0;
    for (uint8_t i = 0; i < s_num_temps; i++) {
        sum += s_temps[i];
    }
    return (int8_t)(sum / s_num_temps);
}

static int8_t GetMaxTemp(uint8_t *max_id)
{
    int8_t max = -128;
    *max_id = 0;
    
    for (uint8_t i = 0; i < s_num_temps; i++) {
        if (s_temps[i] > max) {
            max = s_temps[i];
            *max_id = i;
        }
    }
    return max;
}

static int8_t GetMinTemp(uint8_t *min_id)
{
    int8_t min = 127;
    *min_id = 0;
    
    for (uint8_t i = 0; i < s_num_temps; i++) {
        if (s_temps[i] < min) {
            min = s_temps[i];
            *min_id = i;
        }
    }
    return min;
}

/* -------------------------------------------------------------------------- */
/* Encode J1939 Address Claim (0x18EEFF80)                                    */
/* -------------------------------------------------------------------------- */

void EncodeJ1939Claim(uint8_t *payload)
{
    payload[0] = s_default_claim.unique_id[0];              /* 0xF3 */
    payload[1] = s_default_claim.unique_id[1];              /* 0x00 */
    payload[2] = s_default_claim.unique_id[2];              /* 0x80 */
    payload[3] = s_default_claim.bms_target;                /* 0xF3 */
    payload[4] = s_default_claim.thermistor_module << 3;    /* module index << 3 (module 0 => 0x00) */
    payload[5] = s_default_claim.constant[0];               /* 0x40 */
    payload[6] = s_default_claim.constant[1];               /* 0x1E */
    payload[7] = s_default_claim.constant[2];               /* 0x90 */
}

/* -------------------------------------------------------------------------- */
/* Encode BMS Broadcast (0x1839F380)                                          */
/* Per spec:                                                                  */
/* Byte 0: Thermistor Module Number                                           */
/* Byte 1: Lowest temp (int8_t)                                               */
/* Byte 2: Highest temp (int8_t)                                              */
/* Byte 3: Average temp (int8_t)                                              */
/* Byte 4: Number of thermistors enabled                                       */
/* Byte 5: Highest thermistor ID on module (zero-based)                       */
/* Byte 6: Lowest thermistor ID on module (zero-based)                        */
/* Byte 7: Checksum (sum of all bytes + 0x39 + length)                        */
/* -------------------------------------------------------------------------- */

void EncodeBMSBroadcast(uint8_t *payload)
{
    uint8_t max_id = 0;
    uint8_t min_id = 0;
    int8_t avg = GetAvgTemp();
    int8_t max = GetMaxTemp(&max_id);
    int8_t min = GetMinTemp(&min_id);

    /* Byte 0: Thermistor module index (zero-based). */
    payload[0] = s_default_claim.thermistor_module;
    /* Bytes 1–3: min / max / avg temperatures as signed int8_t */
    payload[1] = (uint8_t)min;
    payload[2] = (uint8_t)max;
    payload[3] = (uint8_t)avg;
    /* Byte 4: number of enabled thermistors */
    payload[4] = (uint8_t)(s_num_temps & 0x7FU);
    /* Byte 5: thermistor ID (zero-based) with the highest temperature */
    payload[5] = max_id;
    /* Byte 6: thermistor ID (zero-based) with the lowest temperature */
    payload[6] = min_id;

    /* Byte 7: Checksum = sum(payload[0..6]) + 0x39 + DLC(8), modulo 256 */
    uint16_t sum = 0x39U + 8U;
    for (uint8_t i = 0; i < 7U; i++) {
        sum += payload[i];
    }
    payload[7] = (uint8_t)sum;
}

/* -------------------------------------------------------------------------- */
/* Encode General Broadcast (0x1838F380)                                      */
/* Byte layout (0-indexed, DLC=8):                                            */
/*   [0-1] Global thermistor ID = module*80 + local_id, little-endian        */
/*   [2]   Thermistor temperature (int8_t stored as uint8_t two's complement) */
/*   [3]   Local thermistor ID                                                 */
/*   [4]   Lowest  temperature on this module                                 */
/*   [5]   Highest temperature on this module                                 */
/*   [6]   Local ID of highest-temperature thermistor (zero-based)            */
/*   [7]   Local ID of lowest-temperature  thermistor (zero-based)            */
/* Cycles through all enabled thermistors (round-robin from CAN_SendMessages) */
/* -------------------------------------------------------------------------- */

void EncodeGeneralBroadcast(uint8_t therm_index, uint8_t *payload)
{
    uint8_t max_id = 0;
    uint8_t min_id = 0;
    int8_t this_temp = (therm_index < s_num_temps) ? s_temps[therm_index] : 0;
    int8_t min = GetMinTemp(&min_id);
    int8_t max = GetMaxTemp(&max_id);

    /* Global thermistor ID: module_index * 80 + local_index.
     * Module 0: IDs 0–79, Module 1: IDs 80–159, etc. */
    uint16_t global_id = (uint16_t)s_default_claim.thermistor_module * 80U
                         + (uint16_t)therm_index;

    /* Bytes 0–1: global thermistor ID, little-endian */
    payload[0] = (uint8_t)(global_id & 0xFFU);
    payload[1] = (uint8_t)((global_id >> 8U) & 0xFFU);
    /* Byte 2: thermistor value as signed int8_t */
    payload[2] = (uint8_t)this_temp;
    /* Byte 3: module-relative thermistor ID */
    payload[3] = (uint8_t)(therm_index & 0x7FU);
    /* Byte 4: lowest temperature on this module */
    payload[4] = (uint8_t)min;
    /* Byte 5: highest temperature on this module */
    payload[5] = (uint8_t)max;
    /* Byte 6: local ID of the thermistor with the highest temperature */
    payload[6] = max_id;
    /* Byte 7: local ID of the thermistor with the lowest temperature */
    payload[7] = min_id;
}

/* -------------------------------------------------------------------------- */
/* Debug: snapshot of last CAN payloads and timing (rate-limited / on demand) */
/* -------------------------------------------------------------------------- */

static void CAN_PrintSnapshot(void)
{
    const uint32_t now_ms = HAL_GetTick();
    LOG_INFO("=== CAN SNAPSHOT @%lums ===", (unsigned long)now_ms);

    /* --- J1939 Address Claim (0x18EEFF80) --- */
    LOG_INFO("J1939Claim 0x18EEFF80  interval=%lums",
             (unsigned long)s_last_claim_interval_ms);
    LOG_INFO("  [%02X %02X %02X %02X %02X %02X %02X %02X]",
             s_last_payload_claim[0], s_last_payload_claim[1],
             s_last_payload_claim[2], s_last_payload_claim[3],
             s_last_payload_claim[4], s_last_payload_claim[5],
             s_last_payload_claim[6], s_last_payload_claim[7]);
    LOG_INFO("  b3=bms_tgt:0x%02X  b4=mod<<3:0x%02X -> module=%u",
             s_last_payload_claim[3],
             s_last_payload_claim[4],
             (unsigned)(s_last_payload_claim[4] >> 3));

    /* --- BMS Broadcast (0x1839F380) --- */
    LOG_INFO("BMS        0x1839F380  interval=%lums",
             (unsigned long)s_last_bms_interval_ms);
    LOG_INFO("  [%02X %02X %02X %02X %02X %02X %02X %02X]",
             s_last_payload_bms[0], s_last_payload_bms[1],
             s_last_payload_bms[2], s_last_payload_bms[3],
             s_last_payload_bms[4], s_last_payload_bms[5],
             s_last_payload_bms[6], s_last_payload_bms[7]);
    LOG_INFO("  b0=mod:%u  b1=lo:%d  b2=hi:%d  b3=avg:%d  b4=en:%u  b5=hiID:%u  b6=loID:%u  b7=chk:0x%02X",
             s_last_payload_bms[0],
             (int)(int8_t)s_last_payload_bms[1],
             (int)(int8_t)s_last_payload_bms[2],
             (int)(int8_t)s_last_payload_bms[3],
             (unsigned)(s_last_payload_bms[4] & 0x7FU),
             s_last_payload_bms[5],
             s_last_payload_bms[6],
             s_last_payload_bms[7]);

    /* --- General Broadcast (0x1838F380) --- */
    LOG_INFO("GEN        0x1838F380  (round-robin thermistor)");
    LOG_INFO("  [%02X %02X %02X %02X %02X %02X %02X %02X]",
             s_last_payload_gen[0], s_last_payload_gen[1],
             s_last_payload_gen[2], s_last_payload_gen[3],
             s_last_payload_gen[4], s_last_payload_gen[5],
             s_last_payload_gen[6], s_last_payload_gen[7]);
    {
        const uint16_t gid = (uint16_t)s_last_payload_gen[0]
                             | ((uint16_t)s_last_payload_gen[1] << 8U);
        LOG_INFO("  b01=globalID:%u  b2=temp:%d  b3=localID:%u  b4=lo:%d  b5=hi:%d  b6=hiID:%u  b7=loID:%u",
                 (unsigned)gid,
                 (int)(int8_t)s_last_payload_gen[2],
                 (unsigned)(s_last_payload_gen[3] & 0x7FU),
                 (int)(int8_t)s_last_payload_gen[4],
                 (int)(int8_t)s_last_payload_gen[5],
                 s_last_payload_gen[6],
                 s_last_payload_gen[7]);
    }
}

/* -------------------------------------------------------------------------- */
/* Debug: dump ADC raw values + converted temperatures                        */
/* -------------------------------------------------------------------------- */

static void Debug_PrintDump(void)
{
    const uint32_t now_ms = HAL_GetTick();
    LOG_INFO("=== DUMP @%lums  n=%u thermistors ===",
             (unsigned long)now_ms, (unsigned)s_num_temps);
    for (uint8_t i = 0U; i < s_num_temps; i++) {
        const uint16_t adc = g_can_ctx.thermistors.thermistor_adc_values[i];
        LOG_INFO("  therm[%u]: ADC=%u  temp=%d%s",
                 (unsigned)i,
                 (unsigned)adc,
                 (int)s_temps[i],
                 (s_temps[i] >= 80) ? "  *** HIGH ***" : "");
    }
}

/* -------------------------------------------------------------------------- */
/* UART command parser — invoked by Debug_PollCommand on complete line        */
/* -------------------------------------------------------------------------- */

static void ProcessCommand(const char *cmd)
{
    if (strcmp(cmd, "dump") == 0) {
        Debug_PrintDump();
    } else if (strcmp(cmd, "can") == 0) {
        CAN_PrintSnapshot();
    } else if (strcmp(cmd, "timing") == 0) {
        LOG_INFO("=== TIMING ===");
        LOG_INFO("  J1939Claim (200ms target): last_interval=%lums",
                 (unsigned long)s_last_claim_interval_ms);
        LOG_INFO("  BMS        (100ms target): last_interval=%lums",
                 (unsigned long)s_last_bms_interval_ms);
    } else if (strncmp(cmd, "therm ", 6) == 0 && cmd[6] >= '0' && cmd[6] <= '9') {
        const uint8_t idx = (uint8_t)(cmd[6] - '0');
        if (idx < s_num_temps) {
            const uint16_t adc = g_can_ctx.thermistors.thermistor_adc_values[idx];
            LOG_INFO("=== THERM %u ===", (unsigned)idx);
            LOG_INFO("  ADC=%u  temp=%d", (unsigned)adc, (int)s_temps[idx]);
            LOG_INFO("  last GEN [%02X %02X %02X %02X %02X %02X %02X %02X]",
                     s_last_payload_gen[0], s_last_payload_gen[1],
                     s_last_payload_gen[2], s_last_payload_gen[3],
                     s_last_payload_gen[4], s_last_payload_gen[5],
                     s_last_payload_gen[6], s_last_payload_gen[7]);
        } else {
            LOG_INFO("therm index out of range (0-%u)",
                     (unsigned)(s_num_temps > 0U ? s_num_temps - 1U : 0U));
        }
    } else if (strcmp(cmd, "stream on") == 0) {
        s_stream_enabled = true;
        s_stream_next_ms = HAL_GetTick();
        LOG_INFO("Stream ON (500ms)");
    } else if (strcmp(cmd, "stream off") == 0) {
        s_stream_enabled = false;
        LOG_INFO("Stream OFF");
    } else {
        LOG_INFO("Commands: dump | can | timing | therm N | stream on | stream off");
    }
}

/* -------------------------------------------------------------------------- */
/* Main Send Function — called from CAN_ServiceTask every loop iteration      */
/*                                                                            */
/* ZERO UART inside the TX path. All logging is rate-limited and separate.    */
/* Temperatures are pre-cached by ConvertAllThermistors() in ADC_ServiceTask. */
/* -------------------------------------------------------------------------- */

void CAN_SendMessages(void)
{
    static uint8_t therm_index = 0U;
    uint8_t payload[8];
    const uint8_t source_address = CAN_GetSourceAddress();
    uint32_t now_ms;
    uint32_t interval_ms;

    /* -----------------------------------------------------------------------
     * 200 ms: J1939 Address Claim (0x18EEFF80)
     *
     *   [0] unique_id[0]    = 0xF3
     *   [1] unique_id[1]    = 0x00
     *   [2] unique_id[2]    = 0x80
    *   [3] bms_target      = 0xF3  (Orion BMS J1939 source address)
    *   [4] module<<3       = 0x00  (module 0: 0<<3=0; module 1: 1<<3=8)
     *   [5] constant        = 0x40
     *   [6] constant        = 0x1E
     *   [7] constant        = 0x90
     * ----------------------------------------------------------------------- */
    if (Timer_Check200msFlag()) {
        now_ms       = HAL_GetTick();
        interval_ms  = (s_last_200ms_tx_ms > 0U) ? (now_ms - s_last_200ms_tx_ms) : 0U;
        s_last_200ms_tx_ms       = now_ms;
        s_last_claim_interval_ms = interval_ms;

        EncodeJ1939Claim(payload);
        (void)memcpy(s_last_payload_claim, payload, 8U);
        (void)CAN_Comm_SendExt(CAN_ApplySourceAddress(THERM_J1939_CLAIM_ID, source_address), payload, 8U);
    }

    /* -----------------------------------------------------------------------
     * 100 ms: BMS Broadcast (0x1839F380) + General Broadcast (0x1838F380)
     *
    * BMS Broadcast byte layout:
    *   [0] module index (0 = first module)
     *   [1] lowest  temp  (int8_t as uint8_t two's complement)
     *   [2] highest temp  (int8_t as uint8_t two's complement)
     *   [3] average temp  (int8_t as uint8_t two's complement)
    *   [4] enabled count
     *   [5] local ID of highest-temp thermistor (zero-based)
     *   [6] local ID of lowest-temp  thermistor (zero-based)
     *   [7] checksum = sum(bytes 0-6) + 0x39 + 8
     *
    * General Broadcast byte layout:
    *   [0-1] global ID = module*80 + local_idx, little-endian
    *         module 0 → IDs 0..79; module 1 → IDs 80..159
     *   [2]   this thermistor temperature (int8_t two's complement)
     *   [3]   local thermistor ID (zero-based)
     *   [4]   module lowest  temp (int8_t)
     *   [5]   module highest temp (int8_t)
     *   [6]   local ID of highest-temp thermistor
     *   [7]   local ID of lowest-temp  thermistor
     * ----------------------------------------------------------------------- */
    if (Timer_Check100msFlag()) {
        now_ms       = HAL_GetTick();
        interval_ms  = (s_last_100ms_tx_ms > 0U) ? (now_ms - s_last_100ms_tx_ms) : 0U;
        s_last_100ms_tx_ms    = now_ms;
        s_last_bms_interval_ms = interval_ms;

        EncodeBMSBroadcast(payload);
        (void)memcpy(s_last_payload_bms, payload, 8U);
        (void)CAN_Comm_SendExt(CAN_ApplySourceAddress(THERM_BMS_BROADCAST_ID, source_address), payload, 8U);

        if (s_num_temps > 0U) {
            EncodeGeneralBroadcast(therm_index, payload);
            (void)memcpy(s_last_payload_gen, payload, 8U);
            (void)CAN_Comm_SendExt(CAN_ApplySourceAddress(THERM_GENERAL_BROADCAST_ID, source_address), payload, 8U);
            therm_index = (uint8_t)((therm_index + 1U) % s_num_temps);
        }
    }

    /* -----------------------------------------------------------------------
    * Rate-limited UART stream (zero overhead when disabled).
    * Enabled by default; use "stream off" command to disable.
     * All blocking UART output lives here — never in the TX blocks above.
     * ----------------------------------------------------------------------- */
    if (s_stream_enabled) {
        const uint32_t now_s = HAL_GetTick();
        if ((int32_t)(now_s - s_stream_next_ms) >= 0) {
            s_stream_next_ms = now_s + 500U;
            CAN_PrintSnapshot();
        }
    }
}

/* -------------------------------------------------------------------------- */
/* UART Debug Command Interface — call every loop iteration (non-blocking)    */
/* -------------------------------------------------------------------------- */

void Debug_PollCommand(void)
{
    uint8_t c = 0U;

    /* Returns immediately (HAL_TIMEOUT) if no byte is waiting in the FIFO. */
    if (HAL_UART_Receive(&g_uart2, &c, 1U, 0U) != HAL_OK) {
        return;
    }

    if (c == (uint8_t)'\r' || c == (uint8_t)'\n') {
        if (s_cmd_len > 0U) {
            s_cmd_buf[s_cmd_len] = '\0';
            ProcessCommand(s_cmd_buf);
            s_cmd_len = 0U;
        }
        return;
    }

    /* Echo received character so the terminal shows what was typed. */
    (void)HAL_UART_Transmit(&g_uart2, &c, 1U, HAL_MAX_DELAY);

    if (s_cmd_len < (uint8_t)(sizeof(s_cmd_buf) - 1U)) {
        s_cmd_buf[s_cmd_len++] = (char)c;
    }
}