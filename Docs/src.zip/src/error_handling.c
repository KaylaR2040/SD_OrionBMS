/*
 * ===========================================================================
 * File: error_handling.c
 * Description: Fatal error handling (trap and signal via LED5).
 * ===========================================================================
 */

// STM32 HAL
#include "stm32g4xx_hal.h"

// Project headers
#include "led.h"
#include "error_handling.h"

/** Busy-wait loop used while blinking the fatal error LED. */
static void error_delay(void)
{
    for (volatile uint32_t i = 0; i < 500000U; ++i) {
        __NOP();
    }
}

/* Fatal error handler that blinks LED5 forever */
void Error_Handler(void)
{
    __disable_irq();
    LED_Init();
    LED_On(LED_ID_LD5);
    while (1) {
        error_delay();
    }
}
