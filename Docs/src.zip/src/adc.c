/*
 * ===========================================================================
 * File: adc.c
 * Description: Internal STM32 ADC helpers (MAX178xx ADC traffic lives in spi.c).
 *
 * Notes:
 *   - Owns on-chip ADC sampling plus optional LED PWM driven from ADC readings.
 * ===========================================================================
 */

// Project headers
#include "led.h"
#include "adc.h"
#include "log.h"
#include "can_messages.h"
#include "can.h"

// C standard library
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define ADC_CONVERSION_TIMEOUT_MS  10U
#define ADC_SAMPLE_TIME            ADC_SAMPLETIME_247CYCLES_5
#define ADC_SETTLE_DELAY_ITERS     64U

#define ADC_PWM_TIMER              TIM1      /* TIM1_CH2 maps to PA9 (LED1) via AF6 */
#define ADC_PWM_CHANNEL            TIM_CHANNEL_2
#define ADC_PWM_GPIO_AF            GPIO_AF6_TIM1
#define ADC_PWM_TIMER_CLK_HZ       10000U
#define ADC_PWM_DEFAULT_FREQ_HZ    2U

#define ADC_MAX_COUNTS             4095U
#define ADC_REF_MV                 3300U
#define ADC_MIN_PWM_MV             50U
/* Minimum ADC counts equivalent to ~50 mV to avoid an unreachable zero duty. */
#define ADC_MIN_PWM_COUNTS         ((ADC_MIN_PWM_MV * ADC_MAX_COUNTS) / ADC_REF_MV)
#define ADC_PWM_CONTROL_CHANNEL    ADC_CHANNEL_1

/*
 * ADC sampling math:
 *   - Sample time = 247.5 cycles and conversion adds 12.5 cycles.
 *   - Total cycles per sample = 260 cycles (longer window improves accuracy).
 *   - Asynchronous ADC clock = 170 MHz (PLL output with DIV1 prescaler).
 *   - Effective sample frequency ~ 170e6 / 260 ~ 653.8 kHz (~1.53 us / sample).
 * The PWM update function leverages this by running every time ADC_ServiceTask()
 * executes, keeping the configured LED's duty cycle in lockstep with the
 * latest conversion. Any reading below 0.05 V is treated as "off" and full
 * scale (~3.3 V) maps to 100% duty.
 */

/** Primary ADC handle used across the application. */
ADC_HandleTypeDef hadc1;

/** Milliseconds to wait before running the ADC task for the first time. */
#define ADC_TASK_INITIAL_DELAY_MS 0U // INST_TEST // 1*(LOOP_TASK_PERIOD_MS/3) // 1000U

/** Period between ADC log snapshots.
 *  Set to 2000ms so the UART-heavy log path does not block every main loop
 *  iteration.  ADC sampling still happens every iteration via the fast path in
 *  ADC_ServiceTask(); only the log output is rate-limited here. */
#define ADC_TASK_PERIOD_MS        2000U

/** Next scheduled timestamp for the ADC log output. */
static uint32_t g_adc_next_log_ms = 0U;

/** TIM handle dedicated to ADC-driven LED PWM control (see ADC_PWM_LED_ID). */
static TIM_HandleTypeDef g_led_pwm_tim;
static uint32_t g_pwm_target_freq_hz = ADC_PWM_DEFAULT_FREQ_HZ;
static uint32_t g_pwm_period_ticks = 0U;
static bool g_led_pwm_requested = (ADC_PWM_LED_USE_PWM != 0);
static bool g_led_pwm_initialized = false;

static void ADC_ConfigLedPwm(void);
static void ADC_UpdateLedPwmDuty(uint16_t adc_counts);
static void ADC_UpdatePwmFromAdc(void);
static void ADC_DelayForSettling(void);
static HAL_StatusTypeDef ADC_PerformConversion(uint16_t *result);
static uint32_t ADC_ComputePeriodTicks(uint32_t freq_hz);

/* Initialize the STM32G4 on-chip ADC */
void ADC_App_Init(void)
{
    __HAL_RCC_ADC12_CLK_ENABLE();

    hadc1.Instance = ADC1;
    hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
    hadc1.Init.Resolution = ADC_RESOLUTION_12B;
    hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
    hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    hadc1.Init.LowPowerAutoWait = DISABLE;
    hadc1.Init.ContinuousConvMode = DISABLE;
    hadc1.Init.NbrOfConversion = 1;
    hadc1.Init.DiscontinuousConvMode = DISABLE;
    hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc1.Init.DMAContinuousRequests = DISABLE;
    hadc1.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    hadc1.Init.OversamplingMode = DISABLE;
    if (HAL_ADC_Init(&hadc1) != HAL_OK) Error_Handler();

    if (HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED) != HAL_OK) Error_Handler();

    if (g_led_pwm_requested) {
        ADC_ConfigLedPwm();
    }
}

/* Blocking read for a single STM32 ADC channel */
uint16_t ADC_App_ReadChannel(uint32_t channel)
{
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = channel;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLE_TIME;
#ifdef ADC_SINGLE_ENDED
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
#endif
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
    if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) return 0;
    ADC_DelayForSettling();
    /* Discard the first conversion after switching channels to bleed off charge. */
    (void)ADC_PerformConversion(NULL);

    uint16_t val = 0U;
    if (ADC_PerformConversion(&val) != HAL_OK) {
        return 0U;
    }
    return val;
}

/* Iterate across the STM32 ADC channels so higher layers get consistent data */
void ADC_App_SampleAll(uint16_t out_vals[ADC_APP_CHANNEL_COUNT])
{
    const uint32_t chans[ADC_APP_CHANNEL_COUNT] = {
        ADC_CHANNEL_1,
        ADC_CHANNEL_2,
        ADC_CHANNEL_5,
        ADC_CHANNEL_6,
        ADC_CHANNEL_7,
        ADC_CHANNEL_8,
        ADC_CHANNEL_9,
        ADC_CHANNEL_11,
        ADC_CHANNEL_14,
        ADC_CHANNEL_15
    };

    if (!out_vals) return;
    for (size_t i = 0; i < ADC_APP_CHANNEL_COUNT; ++i) {
        out_vals[i] = ADC_App_ReadChannel(chans[i]);
    }
}

/* Emit a log snapshot of the STM32 ADC so the CLI can visualize sensor values.
 * NOTE: Does NOT re-sample the ADC.  Values come from the fast-path cache in
 * g_can_ctx.thermistors that ADC_ServiceTask() refreshes every iteration. */
void ADC_App_LogSnapshot(void)
{
    const uint32_t channel_ids[ADC_APP_CHANNEL_COUNT] = {
        1, 2, 5, 6, 7, 8, 9, 11, 14, 15
    };
    const char *channel_pins[ADC_APP_CHANNEL_COUNT] = {
        "PA0", "PA1", "PB14", "PC0", "PC1",
        "PC2", "PC3", "PB12", "PB11", "PB0"
    };

    /* Header label separates ADC dump from prior task output. */
    LOG_INFO("ADC1 snapshot1:");
    for (size_t i = 0; i < ADC_APP_CHANNEL_COUNT; ++i) {
        const uint16_t sample = g_can_ctx.thermistors.thermistor_adc_values[i];
        const uint32_t millivolts =
            ((uint32_t)sample * (uint32_t)ADC_REF_MV) / (uint32_t)ADC_MAX_COUNTS;
        const uint32_t volts_whole = millivolts / 1000U;
        const uint32_t volts_frac = millivolts % 1000U;
        /* Each channel line shows ID, pin, and computed voltage in volts. */
        LOG_INFO("  %sCH%-2lu%s %-5s %s%lu.%03lu V%s",
                 LOG_COLOR_FIELD,
                 (unsigned long)channel_ids[i],
                 LOG_COLOR_RESET,
                 channel_pins[i],
                 LOG_COLOR_VALUE,
                 (unsigned long)volts_whole,
                 (unsigned long)volts_frac,
                 LOG_COLOR_RESET);
    }
    /* Spacer to separate ADC output from subsequent task logs. */
    LOG_INFO("\n");
}

/* Execute the ADC periodic task that toggles LEDs and logs samples */
void ADC_ServiceTask(void)
{
    /* -------------------------------------------------------------------
     * Fast path — runs every main-loop iteration.
     *
     * Sample all ADC channels and refresh the CAN thermistor cache so
     * that CAN_SendMessages() always has up-to-date converted values when
     * its 100 ms flag fires.  Keeping this outside the rate-limited log
     * block ensures the CAN transmit path is never stalled waiting for
     * UART to drain.
     * ------------------------------------------------------------------- */
    uint16_t fast_samples[ADC_APP_CHANNEL_COUNT];
    ADC_App_SampleAll(fast_samples);
    for (uint8_t i = 0U; i < ADC_APP_CHANNEL_COUNT && i < MAX_THERMISTORS; i++) {
        g_can_ctx.thermistors.thermistor_adc_values[i] = fast_samples[i];
    }
    g_can_ctx.thermistors.num_active = ADC_APP_CHANNEL_COUNT;
    /* Convert ADC → °C now so CAN_SendMessages() reads pre-cached s_temps[]. */
    ConvertAllThermistors(g_can_ctx.thermistors.thermistor_adc_values,
                          g_can_ctx.thermistors.num_active);

    if (g_led_pwm_requested && g_led_pwm_initialized) {
        ADC_UpdatePwmFromAdc();
    }

    /* -------------------------------------------------------------------
     * Slow path — rate-limited to ADC_TASK_PERIOD_MS (2000 ms).
     * Only the diagnostic log runs here; sampling was already done above.
     * ------------------------------------------------------------------- */
    const uint32_t now_ms = HAL_GetTick();
    if (g_adc_next_log_ms == 0U) {
        g_adc_next_log_ms = now_ms + ADC_TASK_INITIAL_DELAY_MS;
    }

    if ((int32_t)(now_ms - g_adc_next_log_ms) < 0) {
        return;
    }

    /* Blink/status LEDs: turn off the ADC-driven LED and enable a heartbeat LED */
    LED_Off(LED_ID_LD4);
    LED_On(LED_ID_LD2);
    g_adc_next_log_ms = now_ms + ADC_TASK_PERIOD_MS;
    ADC_App_LogSnapshot();
}

/* Allow main() to request PWM-driven LED control before ADC init */
void ADC_LedPwm_RequestEnable(bool enable)
{
    g_led_pwm_requested = enable;
}

/* Configure TIM1 PWM output for the ADC-driven LED */
static void ADC_ConfigLedPwm(void)
{
    GPIO_InitTypeDef gpio = {0};

    /* Route TIM1 CH2 onto the configured LED pin (PA9 / LED1) using the AF matrix. */
    gpio.Pin = ADC_PWM_LED_PIN;
    gpio.Mode = GPIO_MODE_AF_PP;
    gpio.Pull = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    gpio.Alternate = ADC_PWM_GPIO_AF;
    HAL_GPIO_Init(ADC_PWM_LED_PORT, &gpio);

    __HAL_RCC_TIM1_CLK_ENABLE();

    /*
     * Timer math:
     *   - SystemCoreClock = 80 MHz (HSI 16 MHz, /4, *40, /2).
     *   - Prescaler picks a 10 kHz timer clock:
     *         timer_clk = 80e6 / (prescaler + 1) = 10 kHz.
     *   - Target PWM frequency = g_pwm_target_freq_hz (default 2 Hz).
     *         period_ticks = timer_clk / target.
     *   - PWM reload = period_ticks - 1 (TIM is zero-based).
     * Suggested tests:
     *   1) ADC_SetLedPwmFrequency(ADC_PWM_FREQ_DEMO_SLOW_KHZ) -> 1 Hz (0.001 kHz)
     *      to watch obvious on/off duty changes for debugging.
     *   2) ADC_SetLedPwmFrequency(ADC_PWM_FREQ_DEMO_FAST_KHZ) -> 200 Hz (0.2 kHz)
     *      so the LED appears continuously dimmer/brighter-the typical PWM use case.
     *
     * At 200 Hz the period is 50 ticks (49 after the -1), so duty resolution is ~2%.
     */
    g_led_pwm_tim.Instance = ADC_PWM_TIMER;
    g_led_pwm_tim.Init.Prescaler = (uint32_t)((SystemCoreClock / ADC_PWM_TIMER_CLK_HZ) - 1U);
    g_led_pwm_tim.Init.CounterMode = TIM_COUNTERMODE_UP;
    g_pwm_period_ticks = ADC_ComputePeriodTicks(g_pwm_target_freq_hz);
    g_led_pwm_tim.Init.Period = g_pwm_period_ticks;
    g_led_pwm_tim.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    g_led_pwm_tim.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_PWM_Init(&g_led_pwm_tim) != HAL_OK) {
        Error_Handler();
    }

    TIM_OC_InitTypeDef oc = {0};
    oc.OCMode = TIM_OCMODE_PWM1;
    oc.Pulse = 0U;
    oc.OCPolarity = TIM_OCPOLARITY_HIGH;
    oc.OCFastMode = TIM_OCFAST_DISABLE;
    if (HAL_TIM_PWM_ConfigChannel(&g_led_pwm_tim, &oc, ADC_PWM_CHANNEL) != HAL_OK) {
        Error_Handler();
    }

    if (HAL_TIM_PWM_Start(&g_led_pwm_tim, ADC_PWM_CHANNEL) != HAL_OK) {
        Error_Handler();
    }

    g_led_pwm_initialized = true;
}

/* Translate an ADC reading into a PWM duty cycle */
static void ADC_UpdateLedPwmDuty(uint16_t adc_counts)
{
    uint32_t effective_counts = 0U;
    uint32_t pulse_ticks = 0U;
    const uint32_t max_span = ADC_MAX_COUNTS - ADC_MIN_PWM_COUNTS;

    if (adc_counts <= ADC_MIN_PWM_COUNTS) {
        effective_counts = 0U;
    } else if (adc_counts >= ADC_MAX_COUNTS) {
        effective_counts = max_span;
    } else {
        effective_counts = adc_counts - ADC_MIN_PWM_COUNTS;
    }

    if (g_pwm_period_ticks == 0U) {
        g_pwm_period_ticks = ADC_ComputePeriodTicks(g_pwm_target_freq_hz);
    }

    pulse_ticks = (effective_counts * g_pwm_period_ticks) / max_span;
    __HAL_TIM_SET_COMPARE(&g_led_pwm_tim, ADC_PWM_CHANNEL, pulse_ticks);
}

/* Refresh LED PWM duty based on the latest ADC sample */
static void ADC_UpdatePwmFromAdc(void)
{
    if (!g_led_pwm_initialized) {
        return;
    }

    const uint16_t pwm_counts = ADC_App_ReadChannel(ADC_PWM_CONTROL_CHANNEL);
    ADC_UpdateLedPwmDuty(pwm_counts);
}

/* Burn cycles so the sampling cap settles after a channel switch */
static void ADC_DelayForSettling(void)
{
    /*
     * The ADC sample-and-hold capacitor retains some charge from the prior
     * channel. This short NOP loop burns roughly
     *   ADC_SETTLE_DELAY_ITERS / SystemCoreClock seconds
     * (~0.38 us with 64 iters at 170 MHz) so the capacitor discharges through
     * the newly selected channel before we start a conversion.
     */
    for (volatile uint32_t i = 0; i < ADC_SETTLE_DELAY_ITERS; ++i) {
        __NOP();
    }
}

/* Start a single ADC conversion and optionally return the result */
static HAL_StatusTypeDef ADC_PerformConversion(uint16_t *result)
{
    if (HAL_ADC_Start(&hadc1) != HAL_OK) {
        return HAL_ERROR;
    }
    if (HAL_ADC_PollForConversion(&hadc1, ADC_CONVERSION_TIMEOUT_MS) != HAL_OK) {
        HAL_ADC_Stop(&hadc1);
        return HAL_ERROR;
    }
    if (result) {
        *result = (uint16_t)HAL_ADC_GetValue(&hadc1);
    }
    HAL_ADC_Stop(&hadc1);
    return HAL_OK;
}

/* Convert a target PWM frequency into timer reload ticks */
static uint32_t ADC_ComputePeriodTicks(uint32_t freq_hz)
{
    uint32_t safe_freq = freq_hz;
    uint32_t period_ticks = 0U;

    if (safe_freq == 0U) {
        safe_freq = ADC_PWM_DEFAULT_FREQ_HZ;
    }

    period_ticks = (ADC_PWM_TIMER_CLK_HZ / safe_freq);
    if (period_ticks > 0U) {
        period_ticks -= 1U;
    }
    return period_ticks;
}

/* Update the ADC-driven LED PWM frequency */
void ADC_SetLedPwmFrequency(float freq_khz)
{
    uint32_t freq_hz = 0U;
    uint32_t new_period = 0U;

    /*
     * freq_khz is specified in kilohertz so that callers can express both slow
     * demo settings (e.g., 0.001 kHz = 1 Hz) and fast "dim/bright" settings
     * (e.g., 0.200 kHz = 200 Hz).
     */
    if (freq_khz <= 0.0f) {
        freq_hz = ADC_PWM_DEFAULT_FREQ_HZ;
    } else {
        freq_hz = (uint32_t)(freq_khz * 1000.0f);
        if (freq_hz == 0U) {
            freq_hz = ADC_PWM_DEFAULT_FREQ_HZ;
        }
    }

    new_period = ADC_ComputePeriodTicks(freq_hz);
    g_pwm_target_freq_hz = freq_hz;
    g_pwm_period_ticks = new_period;

    if (!g_led_pwm_requested || !g_led_pwm_initialized) {
        return; /* Store the target so ADC_ConfigLedPwm can apply it later. */
    }

    /* Update ARR and CCR so changes take effect immediately. */
    __HAL_TIM_SET_AUTORELOAD(&g_led_pwm_tim, g_pwm_period_ticks);
    __HAL_TIM_SET_COMPARE(&g_led_pwm_tim,
                          ADC_PWM_CHANNEL,
                          __HAL_TIM_GET_COMPARE(&g_led_pwm_tim, ADC_PWM_CHANNEL));
}
