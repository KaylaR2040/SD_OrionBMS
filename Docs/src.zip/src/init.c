/*
 * ===========================================================================
 * File: init.c
 * Description: System-wide initialization helpers for clocks, GPIO, and HAL.
 *
 * Notes:
 *   - Keeps startup wiring minimal so main() remains orchestration-only.
 * ===========================================================================
 */

// STM32 HAL
#include "stm32g4xx_hal.h"

// Project headers
#include "led.h"
#include "error_handling.h"
#include "init.h"
#include "log.h"
#include "main.h"
#include "clocks.h"

/* Initialize HAL, clocks, GPIO, LEDs, and the logging UART */
void System_AppInit(void)
{
    HAL_Init();
    SystemClock_Config();
    GPIO_App_Init();
    LED_Init();
    UART_Log_Init();
    clocks_configure_all();
}

/* Configure PLL and bus clocks for the STM32G4 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    osc.HSIState = RCC_HSI_ON;
    osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    osc.PLL.PLLM = RCC_PLLM_DIV4;
    osc.PLL.PLLN = 40;
    osc.PLL.PLLR = RCC_PLLR_DIV2;
    osc.PLL.PLLQ = RCC_PLLQ_DIV2;
    osc.PLL.PLLP = RCC_PLLP_DIV7;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) {
        Error_Handler();
    }

    clk.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                    RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV1;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_4) != HAL_OK) {
        Error_Handler();
    }
}

/* Configure shared GPIOs such as the ASCI chip-select pin */
void GPIO_App_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    GPIO_InitTypeDef gpio_cs = {0};
    gpio_cs.Pin = ASCI_CS_Pin;
    gpio_cs.Mode = GPIO_MODE_OUTPUT_PP;
    gpio_cs.Pull = GPIO_NOPULL;
    gpio_cs.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(ASCI_CS_GPIO_Port, &gpio_cs);
    HAL_GPIO_WritePin(ASCI_CS_GPIO_Port, ASCI_CS_Pin, GPIO_PIN_SET);
}
