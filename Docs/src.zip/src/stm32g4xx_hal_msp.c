/*
 * ===========================================================================
 * File: stm32g4xx_hal_msp.c
 * Description: HAL MSP init/de-init hooks configuring clocks, DMA, and interrupts.
 *
 * Notes:
 *   - Called by HAL; keep peripheral-specific setup in their sections.
 * ===========================================================================
 */

// STM32 HAL
#include "stm32g4xx_hal.h"

/* Global MSP init: enable core clocks and power interface */
void HAL_MspInit(void)
{
  __HAL_RCC_SYSCFG_CLK_ENABLE();
  __HAL_RCC_PWR_CLK_ENABLE();
}

/* Configure ADC1 GPIO clocks/pins for analog input sampling */
void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{
  if (hadc->Instance == ADC1) {
    __HAL_RCC_ADC12_CLK_ENABLE();

    /* GPIO clocks for analog inputs */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    GPIO_InitTypeDef g = {0};
    g.Mode = GPIO_MODE_ANALOG;
    g.Pull = GPIO_NOPULL;

    /* ADC1_CH1 (PA0), CH2 (PA1) */
    g.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    HAL_GPIO_Init(GPIOA, &g);

    /* ADC1_CH5 (PB14), CH11 (PB12), CH14 (PB11), CH15 (PB0) */
    g.Pin = GPIO_PIN_14 | GPIO_PIN_12 | GPIO_PIN_11 | GPIO_PIN_0;
    HAL_GPIO_Init(GPIOB, &g);

    /* ADC1_CH6 (PC0), CH7 (PC1), CH8 (PC2), CH9 (PC3) */
    g.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3;
    HAL_GPIO_Init(GPIOC, &g);
  }
}

/* Return ADC1 GPIO and clocks to reset state */
void HAL_ADC_MspDeInit(ADC_HandleTypeDef* hadc)
{
  if (hadc->Instance == ADC1) {
    __HAL_RCC_ADC12_CLK_DISABLE();

    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_0 | GPIO_PIN_1);
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_14 | GPIO_PIN_12 | GPIO_PIN_11 | GPIO_PIN_0);
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);
  }
}

/* Configure FDCAN1 pins, clocks, and NVIC priority */
void HAL_FDCAN_MspInit(FDCAN_HandleTypeDef* hfdcan)
{
  if (hfdcan->Instance == FDCAN1) {
    __HAL_RCC_FDCAN_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef g = {0};
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

    // PA11 = FDCAN1_RX, PA12 = FDCAN1_TX
    g.Pin = GPIO_PIN_11;
    g.Alternate = GPIO_AF9_FDCAN1;
    HAL_GPIO_Init(GPIOA, &g);

    g.Pin = GPIO_PIN_12;
    g.Alternate = GPIO_AF9_FDCAN1;
    HAL_GPIO_Init(GPIOA, &g);

    HAL_NVIC_SetPriority(FDCAN1_IT0_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(FDCAN1_IT0_IRQn);
    HAL_NVIC_SetPriority(FDCAN1_IT1_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(FDCAN1_IT1_IRQn);
  }
}

/* Disable FDCAN1 resources when no longer used */
void HAL_FDCAN_MspDeInit(FDCAN_HandleTypeDef* hfdcan)
{
  if (hfdcan->Instance == FDCAN1) {
    __HAL_RCC_FDCAN_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_11 | GPIO_PIN_12);
    HAL_NVIC_DisableIRQ(FDCAN1_IT0_IRQn);
    HAL_NVIC_DisableIRQ(FDCAN1_IT1_IRQn);
  }
}

/* Configure USART1/USART2 pins and NVIC for UART logging channels */
void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
  if (huart->Instance == USART1) {
    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_4 | GPIO_PIN_5; /* PC4 TX, PC5 RX */
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    g.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOC, &g);

    HAL_NVIC_SetPriority(USART1_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
  }
  else if (huart->Instance == USART2) {
    /* Console logging on PA2/PA3 via ST-Link VCP (USART2) */
    __HAL_RCC_USART2_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_2 | GPIO_PIN_3; /* PA2 TX, PA3 RX */
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    g.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &g);
  }
}
