/*
 * ===========================================================================
 * File: spi.c
 * Description: STM32 SPI helpers plus MAX17841B (spi_max) glue for external ADCs.
 *
 * Notes:
 *   - Periodic task timing is internal; SPI/App services assume main loop is tight.
 *   - MAX17841B register defaults follow datasheet settings to keep link reliable.
 * ===========================================================================
 */

// Project headers
#include "led.h"
#include "log.h"
#include "max17841b.h"
#include "spi.h"
#include "spi_max.h"

// C standard library
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#define SPI_APP_TIMEOUT_MS   50U
#define ASCI_RD_NEXT_MSG_CMD 0x93u
#define ASCI_FRAME_PIPELINE_SKIP 2U

/* LED mapping for SPI visibility:
 * LD1 pulses on master MOSI bytes (mirrored on LD3 for slave RX),
 * LD2 pulses on master MISO samples (mirrored on LD4 for slave TX).
 */
#define LED_MASTER_TX  LED_ID_LD1
#define LED_MASTER_RX  LED_ID_LD2
#define LED_SLAVE_RX   LED_ID_LD3
#define LED_SLAVE_TX   LED_ID_LD4

/** Primary SPI handle for the MAX17841B ASCI interface. */
SPI_HandleTypeDef g_hspi1;

/** Initial delay before the SPI periodic task executes. */
#define SPI_TASK_INITIAL_DELAY_MS 0U // INST_TEST // 2*(LOOP_TASK_PERIOD_MS/3) // 2000U

/** Period between SPI polling/logging operations. */
#define SPI_TASK_PERIOD_MS       0U // INST_TEST // LOOP_TASK_PERIOD_MS // Value = 5000ms * #_Output_Logs -> 15s

/** Next tick value when the SPI periodic task should execute. */
static uint32_t g_spi_next_run_ms = 0U;

/* Configure SPI1 pins and controller for the MAX17841B ASCI bridge (mode 0, <=1 MHz) */
void SPI_App_Init(void)
{
    __HAL_RCC_SPI1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef gpio_spi = {0};
    gpio_spi.Pin = GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
    gpio_spi.Mode = GPIO_MODE_AF_PP;
    gpio_spi.Pull = GPIO_NOPULL;
    gpio_spi.Speed = GPIO_SPEED_FREQ_HIGH;
    gpio_spi.Alternate = GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOA, &gpio_spi);

    g_hspi1.Instance = SPI1;
    g_hspi1.Init.Mode = SPI_MODE_MASTER;
    g_hspi1.Init.Direction = SPI_DIRECTION_2LINES;
    g_hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
    g_hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
    g_hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
    g_hspi1.Init.NSS = SPI_NSS_SOFT;
    g_hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
    g_hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
    g_hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
    g_hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    g_hspi1.Init.CRCPolynomial = 7;
    if (HAL_SPI_Init(&g_hspi1) != HAL_OK) Error_Handler();
}

/* Send an arbitrary byte buffer while asserting CS */
HAL_StatusTypeDef SPI_App_Transmit(const uint8_t *data, size_t len, uint32_t timeout)
{
    if (!data || len == 0) return HAL_ERROR;
    HAL_GPIO_WritePin(SPI_APP_CS_GPIO_Port, SPI_APP_CS_Pin, GPIO_PIN_RESET);
    HAL_StatusTypeDef st = HAL_SPI_Transmit(&g_hspi1, (uint8_t *)data, (uint16_t)len, timeout);
    HAL_GPIO_WritePin(SPI_APP_CS_GPIO_Port, SPI_APP_CS_Pin, GPIO_PIN_SET);
    return st;
}

/* Null-terminated helper built on top of SPI_App_Transmit */
HAL_StatusTypeDef SPI_App_TransmitString(const char *str, uint32_t timeout)
{
    if (!str) return HAL_ERROR;
    size_t len = strlen(str);
    if (len == 0) return HAL_OK;
    return SPI_App_Transmit((const uint8_t *)str, len, timeout);
}

/* Chip-select helpers shared with the MAX17841B shim */
void ASCI_CS_Low(void)
{
    HAL_GPIO_WritePin(SPI_APP_CS_GPIO_Port, SPI_APP_CS_Pin, GPIO_PIN_RESET);
}

void ASCI_CS_High(void)
{
    HAL_GPIO_WritePin(SPI_APP_CS_GPIO_Port, SPI_APP_CS_Pin, GPIO_PIN_SET);
}

/* Execute a RD_NEXT_MSG transaction and copy the payload out */
HAL_StatusTypeDef ASCI_ReadNextMsg(uint8_t *frame, size_t frame_len)
{
    if (!frame || frame_len < 8U) return HAL_ERROR;

    uint8_t rx_buf[11] = {0};
    uint8_t dummy = 0x00u;
    HAL_StatusTypeDef st = HAL_OK;

    ASCI_CS_Low();

    uint8_t cmd = ASCI_RD_NEXT_MSG_CMD;
    st = HAL_SPI_TransmitReceive(&g_hspi1, &cmd, &rx_buf[0], 1, SPI_APP_TIMEOUT_MS);
    if (st == HAL_OK) {
        // LED_Toggle(LED_MASTER_TX);
        // LED_Toggle(LED_SLAVE_RX);
        // LED_Toggle(LED_MASTER_RX);
        // LED_Toggle(LED_SLAVE_TX);
    }

    for (size_t i = 1; i < sizeof(rx_buf) && st == HAL_OK; ++i) {
        st = HAL_SPI_TransmitReceive(&g_hspi1, &dummy, &rx_buf[i], 1, SPI_APP_TIMEOUT_MS);
        if (st == HAL_OK) {
            // LED_Toggle(LED_MASTER_TX);
            // LED_Toggle(LED_SLAVE_RX);
            // LED_Toggle(LED_MASTER_RX);
            // LED_Toggle(LED_SLAVE_TX);
        }
    }

    ASCI_CS_High();

    if (st == HAL_OK) {
        for (size_t i = 0; i < 8; ++i) {
            frame[i] = rx_buf[i + ASCI_FRAME_PIPELINE_SKIP];
        }
    }
    return st;
}

/* Capture an ASCI frame and print the key fields */
void SPI_App_LogSnapshot(void)
{
    uint8_t frame[8] = {0};
    /* Pull one ASCI frame from the MAX17841B-backed stack. */
    HAL_StatusTypeDef st = SPI_Max_RequestCellFrame(frame, sizeof(frame));
    if (st == HAL_OK) {
        uint8_t cmd   = frame[0];
        uint8_t addr  = frame[1];
        uint16_t mv   = (uint16_t)frame[2] | ((uint16_t)frame[3] << 8);
        uint8_t chk   = frame[4];
        uint8_t pec   = frame[5];
        uint8_t alive = frame[6];
        uint8_t pad   = frame[7];
        /* Pretty-print the decoded frame fields with color for readability. */
        LOG_INFO(
            "SPI frame:\r\n"
            "  %sCMD %s0x%02X%s    %sADDR %s0x%02X%s\r\n"
            "  %sVOLT%s %s%5u mV%s\r\n"
            "  %sCHK %s0x%02X%s   %sPEC %s0x%02X%s\r\n"
            "  %sALIVE %s0x%02X%s  %sPAD %s0x%02X%s",
            LOG_COLOR_FIELD, LOG_COLOR_VALUE, cmd, LOG_COLOR_RESET,
            LOG_COLOR_FIELD, LOG_COLOR_VALUE, addr, LOG_COLOR_RESET,
            LOG_COLOR_FIELD, LOG_COLOR_RESET, LOG_COLOR_HILITE, mv, LOG_COLOR_RESET,
            LOG_COLOR_FIELD, LOG_COLOR_VALUE, chk, LOG_COLOR_RESET,
            LOG_COLOR_FIELD, LOG_COLOR_VALUE, pec, LOG_COLOR_RESET,
                 LOG_COLOR_FIELD, LOG_COLOR_VALUE, alive, LOG_COLOR_RESET,
                 LOG_COLOR_FIELD, LOG_COLOR_VALUE, pad, LOG_COLOR_RESET);
        uint16_t aux0 = 0, aux1 = 0;
        /* AUX registers give extra visibility into analog readings. */
        if (SPI_Max_ReadAuxPair(&aux0, &aux1) == HAL_OK) {
            LOG_INFO("  AUX0=%u AUX1=%u (raw counts)", aux0, aux1);
        }
    } else {
        /* Keep the log noisy on failures so the operator sees transport issues. */
        LOG_WARN("ASCI frame read failed (%d)", (int)st);
    }
    /* Spacer to align SPI log output with other periodic tasks. */
    LOG_INFO("\n");
}

/* Execute the SPI periodic task that gathers MAX17841B (spi_max) data */
void SPI_ServiceTask(void)
{
    const uint32_t now_ms = HAL_GetTick();
    if (g_spi_next_run_ms == 0U) {
        g_spi_next_run_ms = now_ms + SPI_TASK_INITIAL_DELAY_MS;
    }

    if ((int32_t)(now_ms - g_spi_next_run_ms) < 0) {
        return;
    }

    LED_Off(LED_ID_LD2);
    LED_On(LED_ID_LD3);
    g_spi_next_run_ms = now_ms + SPI_TASK_PERIOD_MS;
    SPI_App_LogSnapshot();
}

/* -------------------------------------------------------------------------- */
/* ASCI application helpers                                                   */
/* -------------------------------------------------------------------------- */

/** MAX17841B driver context shared across ASCI helpers. */
static max17841b_t g_asci_ctx;

/** MAX1785x device address used for register transactions. */
#define MAX1785X_DEVICE_ADDR           0x00u

/** Command byte for READDEVICE operations. */
#define MAX1785X_CMD_READDEVICE        0x05u

/** Command byte for BS2 block reads. */
#define MAX1785X_CMD_READBLOCK_BS2     0x16u

/** Command byte for READALL operations. */
#define MAX1785X_CMD_READALL           0x03u

/** Version register address from the MAX1785x datasheet. */
#define MAX1785X_VERSION_REG_ADDR      0x00u

/** First auxiliary register address. */
#define MAX1785X_AUX0_REG_ADDR         0x59u

/** Register that exposes cell 1 voltage during READALL operations. */
#define MAX1785X_CELL1_REG_ADDR        0x47u

/** Seed used when building the protocol's data-check byte. */
#define MAX1785X_DATA_CHECK_SEED       0x00u

/** Maximum number of raw bytes returned from ASCI frames. */
#define ASCI_RAW_FRAME_MAX_BYTES       32U

/** Forward declaration for the ASCI silicon version helper. */
static HAL_StatusTypeDef asci_read_version(void);

/** Issue a MAX17841B command payload and capture the reply. */
static HAL_StatusTypeDef asci_issue_command(const uint8_t *payload, size_t payload_len,
                                            uint8_t *frame, size_t frame_len);

/** Poll RX status until a message is reported as ready. */
static HAL_StatusTypeDef asci_wait_msg_ready(uint32_t polls, uint32_t delay_us);

/** Small software delay used between RX status polls. */
static void asci_delay_us_soft(uint32_t us);

/** Compute the device-specific data check byte. */
static uint8_t asci_calc_data_check(const uint8_t *bytes, size_t len);

/** Compute the packet error code for a byte stream. */
static uint8_t asci_calc_pec(const uint8_t *bytes, size_t len);

/** Configure the MAX17841B bridge with the datasheet defaults. */
static HAL_StatusTypeDef asci_configure_bridge_defaults(void);

/** Read the STATUS A/B registers for visibility after init. */
static void asci_log_status_registers(void);

/* Initialize the ASCI stack and confirm connectivity with the daisy chain */
void SPI_Max_Init(void)
{
    g_asci_ctx.hspi = &g_hspi1;
    g_asci_ctx.cs_port = ASCI_CS_GPIO_Port;
    g_asci_ctx.cs_pin = ASCI_CS_Pin;

    HAL_StatusTypeDef st = max17841b_init(&g_asci_ctx);
    if (st != HAL_OK) {
        LOG_ERROR("MAX17841B init failed");
        Error_Handler();
    }

    st = asci_configure_bridge_defaults();
    if (st != HAL_OK) {
        LOG_ERROR("MAX17841B register init failed (%d)", (int)st);
        Error_Handler();
    }
    asci_log_status_registers();

    /* Kick the daisy chain with HELLO ALL so we know the link is alive. */
    const uint8_t hello_payload[] = { 0x57u, 0x00u, 0x00u };
    uint8_t hello_resp[5] = {0};
    st = asci_issue_command(hello_payload, sizeof(hello_payload), hello_resp, sizeof(hello_resp));
    if (st == HAL_OK) {
        LOG_INFO("HELLOALL resp %02X %02X %02X %02X %02X",
                 hello_resp[0], hello_resp[1], hello_resp[2], hello_resp[3], hello_resp[4]);
    } else {
        LOG_WARN("HELLOALL failed (%d)", (int)st);
    }
    (void)asci_read_version();
}

/* Request a READALL response and copy it into the provided buffer */
HAL_StatusTypeDef SPI_Max_RequestCellFrame(uint8_t *frame, size_t len)
{
    if (!frame || len == 0U) {
        return HAL_ERROR;
    }

    uint8_t payload[5] = {0};

    /* Populate the command field (READALL) and the target register (CELL1). */
    payload[0] = MAX1785X_CMD_READALL;
    payload[1] = MAX1785X_CELL1_REG_ADDR;

    /* The protocol expects a data-check byte before the PEC byte. */
    payload[2] = asci_calc_data_check(payload, 2U);

    /* The PEC covers every byte up to (and including) the data-check. */
    payload[3] = asci_calc_pec(payload, 3U);

    /* The final byte remains zero and acts as padding/alive counter seed. */
    payload[4] = 0x00u;

    return asci_issue_command(payload, sizeof(payload), frame, len);
}

/* Read two AUX registers and return their raw counts */
HAL_StatusTypeDef SPI_Max_ReadAuxPair(uint16_t *aux0_counts, uint16_t *aux1_counts)
{
    if (!aux0_counts || !aux1_counts) {
        return HAL_ERROR;
    }

    uint8_t payload[6] = {
        MAX1785X_CMD_READBLOCK_BS2,
        MAX1785X_DEVICE_ADDR,
        MAX1785X_AUX0_REG_ADDR,
        0x00, 0x00, 0x00
    };
    payload[3] = asci_calc_data_check(payload, 3);
    payload[4] = asci_calc_pec(payload, 4);
    uint8_t resp[12] = {0};
    HAL_StatusTypeDef st = asci_issue_command(payload, sizeof(payload), resp, sizeof(resp));
    if (st != HAL_OK) {
        return st;
    }
    if (resp[1] != MAX1785X_CMD_READBLOCK_BS2) {
        return HAL_ERROR;
    }
    *aux0_counts = (uint16_t)resp[4] | ((uint16_t)resp[5] << 8);
    *aux1_counts = (uint16_t)resp[6] | ((uint16_t)resp[7] << 8);
    return HAL_OK;
}

/* Issue a MAX17841B command payload and collect the returned ASCI frame */
static HAL_StatusTypeDef asci_issue_command(const uint8_t *payload, size_t payload_len,
                                            uint8_t *frame, size_t frame_len)
{
    if (!payload || payload_len == 0U || !frame || frame_len == 0U) {
        return HAL_ERROR;
    }

    HAL_StatusTypeDef st = max17841b_clear_tx_buf(&g_asci_ctx);
    if (st != HAL_OK) {
        return st;
    }
    st = max17841b_clear_rx_buf(&g_asci_ctx);
    if (st != HAL_OK) {
        return st;
    }

    st = max17841b_load_queue(&g_asci_ctx, payload, payload_len);
    if (st != HAL_OK) {
        return st;
    }
    st = max17841b_start_tx(&g_asci_ctx);
    if (st != HAL_OK) {
        return st;
    }
    st = asci_wait_msg_ready(32U, 200U);
    if (st != HAL_OK) {
        return st;
    }

    if ((frame_len + 2U) > ASCI_RAW_FRAME_MAX_BYTES) {
        return HAL_ERROR;
    }
    uint8_t raw[ASCI_RAW_FRAME_MAX_BYTES] = {0};
    st = max17841b_read_next_msg_raw(&g_asci_ctx, raw, frame_len + 2U);
    if (st == HAL_OK) {
        (void)memcpy(frame, &raw[2], frame_len);
    }
    return st;
}

/* Poll RX status until a message becomes available */
static HAL_StatusTypeDef asci_wait_msg_ready(uint32_t polls, uint32_t delay_us)
{
    uint8_t status = 0;
    for (uint32_t i = 0; i < polls; ++i) {
        HAL_StatusTypeDef st = max17841b_read_rx_status(&g_asci_ctx, &status);
        if (st != HAL_OK) {
            return st;
        }
        if (status & MAX17841B_RXSTAT_MSG_AVAIL) {
            return HAL_OK;
        }
        if (delay_us) {
            asci_delay_us_soft(delay_us);
        }
    }
    return HAL_TIMEOUT;
}

/* Short software delay for spacing out RX polls */
static void asci_delay_us_soft(uint32_t us)
{
    uint32_t cycles = (SystemCoreClock / 1000000U);
    if (cycles == 0U) {
        cycles = 1U;
    }
    const uint32_t total = cycles * us;
    for (uint32_t i = 0; i < total; ++i) {
        __NOP();
    }
}

/* Build the data-check byte required by the ASCI protocol */
static uint8_t asci_calc_data_check(const uint8_t *bytes, size_t len)
{
    uint16_t sum = 0;
    for (size_t i = 0; i < len; ++i) {
        sum += bytes[i];
    }
    return (uint8_t)(sum & 0xFFu);
}

/* Compute the reflected CRC8 PEC for an ASCI byte stream */
static uint8_t asci_calc_pec(const uint8_t *bytes, size_t len)
{
    /* Polynomial 0xA6 (reflected form of x^8 + x^5 + x^2 + x + 1). */
    const uint8_t polynomial = 0xA6u;
    uint8_t crc = 0x00u;

    if (!bytes || len == 0U) {
        return crc;
    }

    for (size_t index = 0U; index < len; ++index) {
        crc = (uint8_t)(crc ^ bytes[index]);

        for (uint8_t bit = 0U; bit < 8U; ++bit) {
            const bool msb_set = ((crc & 0x80u) != 0U);
            crc = (uint8_t)(crc << 1U);
            if (msb_set) {
                crc = (uint8_t)(crc ^ polynomial);
            }
        }
    }

    return crc;
}

/* Program MAX17841B configuration registers with datasheet defaults */
static HAL_StatusTypeDef asci_configure_bridge_defaults(void)
{
    HAL_StatusTypeDef status = HAL_OK;

    /* Always start with empty FIFOs so the subsequent register writes land cleanly. */
    status = max17841b_clear_tx_buf(&g_asci_ctx);
    if (status != HAL_OK) {
        return status;
    }
    status = max17841b_clear_rx_buf(&g_asci_ctx);
    if (status != HAL_OK) {
        return status;
    }

    /* Disable interrupt forwarding while we configure the bridge. */
    status = max17841b_write_reg(&g_asci_ctx, MAX17841B_REG_RX_INT_EN, 0x00u);
    if (status != HAL_OK) {
        return status;
    }
    status = max17841b_write_reg(&g_asci_ctx, MAX17841B_REG_TX_INT_EN, 0x00u);
    if (status != HAL_OK) {
        return status;
    }

    /* Clear any stale flags that might survive a warm reset. */
    status = max17841b_write_reg(&g_asci_ctx, MAX17841B_REG_RX_INT_FLAGS, 0x00u);
    if (status != HAL_OK) {
        return status;
    }
    status = max17841b_write_reg(&g_asci_ctx, MAX17841B_REG_TX_INT_FLAGS, 0x80u);
    if (status != HAL_OK) {
        return status;
    }

    /* Program configuration registers with the datasheet defaults. */
    status = max17841b_write_reg(&g_asci_ctx, MAX17841B_REG_CONFIG_1, MAX17841B_CONFIG1_DEFAULT);
    if (status != HAL_OK) {
        return status;
    }
    status = max17841b_write_reg(&g_asci_ctx, MAX17841B_REG_CONFIG_2, MAX17841B_CONFIG2_DEFAULT);
    if (status != HAL_OK) {
        return status;
    }
    status = max17841b_write_reg(&g_asci_ctx, MAX17841B_REG_CONFIG_3, MAX17841B_CONFIG3_DEFAULT);
    if (status != HAL_OK) {
        return status;
    }

    return HAL_OK;
}

/* Log MAX17841B status registers for visibility after init */
static void asci_log_status_registers(void)
{
    uint8_t status_a = 0U;
    uint8_t status_b = 0U;

    (void)max17841b_read_reg(&g_asci_ctx, MAX17841B_REG_STATUS_A, &status_a);
    (void)max17841b_read_reg(&g_asci_ctx, MAX17841B_REG_STATUS_B, &status_b);

    LOG_INFO("ASCI status A=0x%02X B=0x%02X", status_a, status_b);
}

/* Read and log the MAX1785x device version register */
static HAL_StatusTypeDef asci_read_version(void)
{
    uint8_t payload[5] = {
        MAX1785X_CMD_READDEVICE,
        MAX1785X_VERSION_REG_ADDR,
        0x00, 0x00, 0x00
    };
    payload[2] = asci_calc_data_check(payload, 2);
    payload[3] = asci_calc_pec(payload, 3);
    uint8_t resp[8] = {0};
    HAL_StatusTypeDef st = asci_issue_command(payload, sizeof(payload), resp, sizeof(resp));
    if (st != HAL_OK) {
        return st;
    }
    if (resp[1] != MAX1785X_CMD_READDEVICE) {
        return HAL_ERROR;
    }
    uint16_t version = (uint16_t)resp[3] << 8 | resp[2];
    LOG_INFO("MAX17854 version 0x%04X", version);
    return HAL_OK;
}

/* -------------------------------------------------------------------------- */
/* MAX17841B driver implementation                                            */
/* -------------------------------------------------------------------------- */

/** Timeout for individual SPI bytes when talking to the MAX17841B. */
#define MAX17841B_SPI_TIMEOUT_MS  25U

/** Internal LED identifier used for master MOSI activity. */
#define LED_MASTER_TX_ID  LED_ID_LD1

/** Internal LED identifier used for master MISO activity. */
#define LED_MASTER_RX_ID  LED_ID_LD2

/** Internal LED identifier used for slave TX indication. */
#define LED_SLAVE_TX_ID   LED_ID_LD3

/** Internal LED identifier used for slave RX indication. */
#define LED_SLAVE_RX_ID   LED_ID_LD4

/** No-op hook that can pulse LEDs when activity is desired. */
static void max17841b_led_pulse(led_id_t id)
{
    (void)id;
}

/** Assert the MAX17841B chip-select line. */
static void max17841b_cs_low(max17841b_t *dev)
{
    HAL_GPIO_WritePin(dev->cs_port, dev->cs_pin, GPIO_PIN_RESET);
}

/** Release the MAX17841B chip-select line. */
static void max17841b_cs_high(max17841b_t *dev)
{
    HAL_GPIO_WritePin(dev->cs_port, dev->cs_pin, GPIO_PIN_SET);
}

/** Blocking SPI transmit helper used by register/buffer routines. */
static HAL_StatusTypeDef max17841b_spi_tx(max17841b_t *dev, const uint8_t *tx, size_t len)
{
    if (!dev || !dev->hspi) {
        return HAL_ERROR;
    }
    if (len == 0U) {
        return HAL_OK;
    }
    if (!tx) {
        return HAL_ERROR;
    }

    HAL_StatusTypeDef st = HAL_OK;
    for (size_t i = 0; i < len && st == HAL_OK; ++i) {
        uint8_t byte = tx[i];
        st = HAL_SPI_Transmit(dev->hspi, &byte, 1, MAX17841B_SPI_TIMEOUT_MS);
        if (st == HAL_OK) {
            max17841b_led_pulse(LED_MASTER_TX_ID);
            max17841b_led_pulse(LED_SLAVE_RX_ID);
        }
    }
    return st;
}

/** Blocking SPI transmit/receive helper for MAX17841B operations. */
static HAL_StatusTypeDef max17841b_spi_txrx(max17841b_t *dev, const uint8_t *tx, uint8_t *rx, size_t len)
{
    if (!dev || !dev->hspi) {
        return HAL_ERROR;
    }
    if (len == 0U) {
        return HAL_OK;
    }

    HAL_StatusTypeDef st = HAL_OK;
    uint8_t rx_byte = 0U;
    for (size_t i = 0; i < len && st == HAL_OK; ++i) {
        uint8_t tx_byte = tx ? tx[i] : 0x00u;
        st = HAL_SPI_TransmitReceive(dev->hspi, &tx_byte, &rx_byte, 1, MAX17841B_SPI_TIMEOUT_MS);
        if (st == HAL_OK) {
            if (rx) {
                rx[i] = rx_byte;
            }
            max17841b_led_pulse(LED_MASTER_TX_ID);
            max17841b_led_pulse(LED_SLAVE_RX_ID);
            max17841b_led_pulse(LED_MASTER_RX_ID);
            max17841b_led_pulse(LED_SLAVE_TX_ID);
        }
    }
    return st;
}

/* Bring the MAX17841B out of reset and validate pointers */
HAL_StatusTypeDef max17841b_init(max17841b_t *dev)
{
    if (!dev || !dev->hspi || !dev->cs_port) {
        return HAL_ERROR;
    }
    max17841b_cs_high(dev);
    HAL_Delay(1);
    return HAL_OK;
}

/* Write a single MAX17841B register (even addresses only) */
HAL_StatusTypeDef max17841b_write_reg(max17841b_t *dev, uint8_t reg_addr, uint8_t value)
{
    if (!dev) {
        return HAL_ERROR;
    }
    if ((reg_addr & 0x01u) != 0u) {
        return HAL_ERROR;
    }

    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &reg_addr, 1);
    if (st == HAL_OK) {
        st = max17841b_spi_tx(dev, &value, 1);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Read a single MAX17841B register (odd addresses only) */
HAL_StatusTypeDef max17841b_read_reg(max17841b_t *dev, uint8_t reg_addr, uint8_t *value)
{
    if (!dev || !value) {
        return HAL_ERROR;
    }
    if ((reg_addr & 0x01u) == 0u) {
        return HAL_ERROR;
    }

    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &reg_addr, 1);
    if (st == HAL_OK) {
        st = max17841b_spi_txrx(dev, NULL, value, 1);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Write a sequence of adjacent registers beginning at start_addr */
HAL_StatusTypeDef max17841b_write_reg_multi(max17841b_t *dev, uint8_t start_addr, const uint8_t *data, size_t len)
{
    if (!dev || !data || len == 0U) {
        return HAL_ERROR;
    }
    if ((start_addr & 0x01u) != 0u) {
        return HAL_ERROR;
    }

    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &start_addr, 1);
    if (st == HAL_OK) {
        st = max17841b_spi_tx(dev, data, len);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Read multiple registers starting at start_addr */
HAL_StatusTypeDef max17841b_read_reg_multi(max17841b_t *dev, uint8_t start_addr, uint8_t *data, size_t len)
{
    if (!dev || !data || len == 0U) {
        return HAL_ERROR;
    }
    if ((start_addr & 0x01u) == 0u) {
        return HAL_ERROR;
    }

    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &start_addr, 1);
    if (st == HAL_OK) {
        st = max17841b_spi_txrx(dev, NULL, data, len);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Run a buffer-write command such as load-queue */
HAL_StatusTypeDef max17841b_write_buffer_cmd(max17841b_t *dev, uint8_t cmd, const uint8_t *data, size_t len)
{
    if (!dev) {
        return HAL_ERROR;
    }
    if (len > 0U && !data) {
        return HAL_ERROR;
    }

    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &cmd, 1);
    if (st == HAL_OK && len > 0U) {
        st = max17841b_spi_tx(dev, data, len);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Run a buffer-read command such as read-next-message */
HAL_StatusTypeDef max17841b_read_buffer_cmd(max17841b_t *dev, uint8_t cmd, uint8_t *data, size_t len)
{
    if (!dev) {
        return HAL_ERROR;
    }
    if (len > 0U && !data) {
        return HAL_ERROR;
    }

    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &cmd, 1);
    if (st == HAL_OK && len > 0U) {
        st = max17841b_spi_txrx(dev, NULL, data, len);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Load the ASCI transmit queue with the provided payload */
HAL_StatusTypeDef max17841b_load_queue(max17841b_t *dev, const uint8_t *payload, size_t len)
{
    if (!dev || !payload || len == 0U || len > 255U) {
        return HAL_ERROR;
    }

    uint8_t hdr[2] = { MAX17841B_CMD_WR_LD_Q, (uint8_t)len };
    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, hdr, 2);
    if (st == HAL_OK) {
        st = max17841b_spi_tx(dev, payload, len);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Send START_TX so the MAX17841B shifts out the queued payload */
HAL_StatusTypeDef max17841b_start_tx(max17841b_t *dev)
{
    if (!dev) {
        return HAL_ERROR;
    }
    uint8_t cmd = MAX17841B_CMD_START_TX;
    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &cmd, 1);
    max17841b_cs_high(dev);
    return st;
}

/* Read the RX status register for polling */
HAL_StatusTypeDef max17841b_read_rx_status(max17841b_t *dev, uint8_t *status)
{
    if (!dev || !status) {
        return HAL_ERROR;
    }
    uint8_t cmd = MAX17841B_CMD_RD_RX_STATUS;
    uint8_t rx = 0U;
    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &cmd, 1);
    if (st == HAL_OK) {
        st = max17841b_spi_txrx(dev, NULL, &rx, 1);
    }
    max17841b_cs_high(dev);
    if (st == HAL_OK) {
        *status = rx;
    }
    return st;
}

/* Clock out the next raw ASCI message (header + payload) */
HAL_StatusTypeDef max17841b_read_next_msg_raw(max17841b_t *dev, uint8_t *data, size_t len)
{
    if (!dev || !data || len == 0U) {
        return HAL_ERROR;
    }
    uint8_t cmd = MAX17841B_CMD_RD_NEXT_MSG;
    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &cmd, 1);
    if (st == HAL_OK) {
        st = max17841b_spi_txrx(dev, NULL, data, len);
    }
    max17841b_cs_high(dev);
    return st;
}

/* Send the CLR_TX command */
HAL_StatusTypeDef max17841b_clear_tx_buf(max17841b_t *dev)
{
    if (!dev) {
        return HAL_ERROR;
    }
    uint8_t cmd = MAX17841B_CMD_CLR_TX_BUF;
    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &cmd, 1);
    max17841b_cs_high(dev);
    return st;
}

/* Send the CLR_RX command */
HAL_StatusTypeDef max17841b_clear_rx_buf(max17841b_t *dev)
{
    if (!dev) {
        return HAL_ERROR;
    }
    uint8_t cmd = MAX17841B_CMD_CLR_RX_BUF;
    max17841b_cs_low(dev);
    HAL_StatusTypeDef st = max17841b_spi_tx(dev, &cmd, 1);
    max17841b_cs_high(dev);
    return st;
}
