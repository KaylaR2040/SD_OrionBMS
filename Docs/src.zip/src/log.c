/*
 * ===========================================================================
 * File: log.c
 * Description: UART-backed logging helpers for colorized formatted output.
 * ===========================================================================
 */

// STM32 HAL
#include "stm32g4xx_hal.h"

// Project headers
#include "error_handling.h"
#include "log.h"

// C standard library
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

/** UART handle dedicated to console logging. */
UART_HandleTypeDef g_uart2;

/* Default runtime toggle for UART logging. Set to LOGGING_DISABLED to silence logs. */
bool uart_log = LOGGING_ENABLED;

/** Cached UART pointer used by the lightweight logging layer. */
static UART_HandleTypeDef *log_uart = NULL;

/** Log level tags printed ahead of each line. */
static const char *const level_tags[LOG_LEVEL_COUNT] = {
    "[INFO]",
    "[WARN]",
    "[ERROR]",
    "[DEBUG]"
};

/** ANSI color codes that correspond to each log level tag. */
static const char *const level_colors[LOG_LEVEL_COUNT] = {
    LOG_COLOR_INFO,
    LOG_COLOR_WARN,
    LOG_COLOR_ERROR,
    LOG_COLOR_DEBUG
};

/* Initialize USART2 so Log_Printf can stream to the host PC */
void UART_Log_Init(void)
{
    if (!uart_log) {
        /* Logging disabled: keep UART idle. */
        log_uart = NULL;
        return;
    }

    g_uart2.Instance = USART2;
    g_uart2.Init.BaudRate = 115200;
    g_uart2.Init.WordLength = UART_WORDLENGTH_8B;
    g_uart2.Init.StopBits = UART_STOPBITS_1;
    g_uart2.Init.Parity = UART_PARITY_NONE;
    g_uart2.Init.Mode = UART_MODE_TX_RX;
    g_uart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    g_uart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&g_uart2) != HAL_OK) {
        Error_Handler();
    }

    /* Point the logging layer at the initialized UART. */
    Log_Init(&g_uart2);
}

/* Bind the logging layer to the provided UART handle */
void Log_Init(UART_HandleTypeDef *huart)
{
    /* Caller owns the UART lifetime; we only cache the pointer. */
    log_uart = huart;
}

/* Emit a formatted, colorized log line over UART */
void Log_Printf(log_level_t level, const char *fmt, ...)
{
    if (!uart_log || !log_uart || level >= LOG_LEVEL_COUNT || fmt == NULL) {
        return;
    }

    /* Render the formatted message into a local buffer. */
    char line[256];
    va_list ap;
    va_start(ap, fmt);
    int len = vsnprintf(line, sizeof(line), fmt, ap);
    va_end(ap);
    if (len < 0) {
        return;
    }
    if ((size_t)len >= sizeof(line)) {
        len = (int)sizeof(line) - 1;
    }

    /* Prefix with level tag + color for clarity on the console. */
    const char *color = level_colors[level];
    const char *tag = level_tags[level];

    /* Emit ANSI color, tag, payload, then reset color. */
    HAL_UART_Transmit(log_uart, (uint8_t *)color, (uint16_t)strlen(color), HAL_MAX_DELAY);
    HAL_UART_Transmit(log_uart, (uint8_t *)tag, (uint16_t)strlen(tag), HAL_MAX_DELAY);
    HAL_UART_Transmit(log_uart, (uint8_t *)" ", 1, HAL_MAX_DELAY);
    HAL_UART_Transmit(log_uart, (uint8_t *)line, (uint16_t)len, HAL_MAX_DELAY);
    HAL_UART_Transmit(log_uart, (uint8_t *)LOG_COLOR_RESET, (uint16_t)strlen(LOG_COLOR_RESET), HAL_MAX_DELAY);
    /* Always end log entries with CRLF for terminal line discipline. */
    const uint8_t newline[2] = {'\r', '\n'};
    HAL_UART_Transmit(log_uart, newline, 2, HAL_MAX_DELAY);
}
