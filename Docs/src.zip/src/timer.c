/*
 * File: timer.c
 * Description: Hardware timer for 100ms and 200ms CAN message triggers
 */

#include "stm32g4xx_hal.h"
#include "timer.h"

#include <stdbool.h>
#include <stdint.h>

#define TIMER_CLK_HZ        10000u
#define TIMER_PERIOD        100u
#define TICKS_FOR_100MS     10u
#define TICKS_FOR_200MS     20u

TIM_HandleTypeDef g_htim6;

volatile bool g_flag_100ms = false;
volatile bool g_flag_200ms = false;

static volatile uint32_t s_counter_100ms = 0u;
static volatile uint32_t s_counter_200ms = 0u;

void Timer_Init(void)
{
    __HAL_RCC_TIM6_CLK_ENABLE();

    g_htim6.Instance = TIM6;
    g_htim6.Init.Prescaler = (SystemCoreClock / TIMER_CLK_HZ) - 1u;
    g_htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
    g_htim6.Init.Period = TIMER_PERIOD - 1u;
    g_htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    HAL_TIM_Base_Init(&g_htim6);
    HAL_NVIC_SetPriority(TIM6_DAC_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);
    HAL_TIM_Base_Start_IT(&g_htim6);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6) {
        s_counter_100ms++;
        if (s_counter_100ms >= TICKS_FOR_100MS) {
            s_counter_100ms = 0u;
            g_flag_100ms = true;
        }

        s_counter_200ms++;
        if (s_counter_200ms >= TICKS_FOR_200MS) {
            s_counter_200ms = 0u;
            g_flag_200ms = true;
        }
    }
}

bool Timer_Check100msFlag(void)
{
    if (g_flag_100ms) {
        g_flag_100ms = false;
        return true;
    }
    return false;
}

bool Timer_Check200msFlag(void)
{
    if (g_flag_200ms) {
        g_flag_200ms = false;
        return true;
    }
    return false;
}